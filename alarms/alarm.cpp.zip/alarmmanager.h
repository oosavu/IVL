#ifndef ALARMMANAGER_H
#define ALARMMANAGER_H

#include <QDebug>
#include <QQmlContext>
#include <QFile>
#include <QMap>
#include "alarmmodel.h"

/// размер буфера в ПЗУ
#define ALARM_BUFER_SIZE 100

//class AlarmModel;

/**
 * Класс менеджера тревог. Является классом одиночкой.
 * Предназначен для централизации работы с тревогами.
 * Для остальной части программы на c++ предоставляет всего три функции: openAlarm closeAlarm и serviceAlarms
 * Для QML расшаривает модели для списка текущих тревог, отложенных тревог и журнала тревог,
 * а так же главную тревогу. Так же из QML доступны функции setAllAlarmsWatched() и freeAlarms() для
 * отчистки списка просмотренных тревог и переинициализации кольцевого буфера тревог
 * TODO подумать может работу с файлом вынести в отдельный класс
 * TODO реализовать различность тревог (например не все попадают в журнал).
 */
class AlarmManager : public QObject
{
    Q_OBJECT
    /// свойство ID главной тревоги
    Q_PROPERTY(AlarmId::Ids mainAlarm READ getMainAlarm NOTIFY mainAlarmChanged)
    /// свойство приоритета главной тревоги
    Q_PROPERTY(AlarmId::Priorities mainPriority READ getMainPriority NOTIFY mainAlarmChanged)
    /// свойство доступности главной тревоги
    Q_PROPERTY(bool avilablity READ getMainAvilablity NOTIFY mainAlarmChanged)
    /// свойство времени главной тревоги (TODO нужно ли оно)
    Q_PROPERTY(QDateTime mainDataTime READ getMainDataTime NOTIFY mainAlarmChanged)
public:

    /**
     * функция открытия тревоги. Проверяет, есть ли тревога среди открытых,
     * если нет, то создает ее, записывает в ПЗУ, добавляет в модели alarms и currentAlarms
     * @param id номер тревоги для открытия.
     * @return true если тревога была открыта, false, если тревога была открыта ранее
     */
    bool openAlarm(AlarmId::Ids id);

    /**
     * функция закрытия тревоги. Проверяет, есть ли тревога среди открытых. Если да -
     * закрывает её, убирает из списка текущих, добавляет в список непросмотренных
     * @param id номер тревоги для закрытия.
     * @return true если тревога была заткрыта, false, если тревога не была закрыта (в данный момент не была открыта)
     */
    bool closeAlarm(AlarmId::Ids id);

    /**
     * Функция установки тревоги в соответствии с флагом В случае \ref needToOpen == true
     * открывает данную тревогу, иначе закрывает её.
     * @param needToOpen булевское значение, на основании которого делается вывод о необходимости снятия\закрытия тревоги
     * @param id Номер тревоги, закрыть/открыть которую в соответствии с @ref needToOpen
     * @return true, если состояние открытости/закрытости данной тревоги было изменено в данной функции.
     */
    bool serviceAlarms(AlarmId::Ids id, bool needToOpen);


    /// Функция для QML, нужна для обозначения всех тревог просмотренными.
    Q_INVOKABLE void setAllAlarmsWatched();

    /// Функция для QML для отчистки буфера тревог.
    Q_INVOKABLE void freeAlarms();
    void bindContext(QQmlContext* ctx);

    Q_INVOKABLE
    void openAlarmQml(int id){ openAlarm(AlarmId::Ids(id));}
    Q_INVOKABLE
    void closeAlarmQml(int id){ closeAlarm(AlarmId::Ids(id));}

    /// функция для реализации свойства ID главной тревоги для QML
    AlarmId::Ids getMainAlarm()const;
    /// функция для реализации свойства приоритета главной тревоги для QML
    AlarmId::Priorities getMainPriority()const;
    /// функция для реализации свойства времени главной тревоги для QML
    QDateTime getMainDataTime()const;
    /// функция для реализации свойства присутствия главной тревоги для QML
    bool getMainAvilablity()const;

    /// метод получения ссылки на объект
    static AlarmManager* instance();
private:

    /// конструктор объекта. Производит чтение буфера ПЗУ, инициализирует списки тревог
    explicit AlarmManager(QObject *parent = 0);
    /// указатель на себя
    static AlarmManager* _self;

    /// список всех тревог
    QList<Alarm*> alarms;
    /// список текущих тревог
    QList<Alarm*> currentAlarms;
    /// список непросмотренных тревог
    QList<Alarm*> unwatchedAlarms;

    /// указатель на файл (это пока файл, потом может просто будет область ПЗУ или БД)
    QFile alarmFile;
    /// индексы головы и хвоста кольцевого буфера
    quint16 head,tail;

    /// указатель на главную ошибку
    Alarm* mainAlarm;
    /// флаг, определяющий наличие главной ошибки
    /// (показывать ли её в верху экрана)
    bool avilableMainAlarm;

    /// модель для журнала тревог
    AlarmModel * alarmmodelAll;
    /// модель для непросмотренных тревог
    AlarmModel * alarmmodelUnwatched;
    /// модель для активных тревог
    AlarmModel * alarmmodelCurrent;


signals:

    /// сигнал для информировании QML о изменении главной ошибки.
    void mainAlarmChanged();


//    void addingCurrentAlarm(int pos);
//    void closedCurrentAlarm(int pos);

};

#endif // ALARMMANAGER_H
