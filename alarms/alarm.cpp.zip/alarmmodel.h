#ifndef AlarmModel_H
#define AlarmModel_H

#include <QObject>
#include <QAbstractListModel>
#include <QDebug>

#include "alarm.h"

/** класс модели списка тревог.
 * нужен для предоставления ListView в QML.
 * Данные представлены в списке alarmList.
 *
**/

class AlarmModel : public QAbstractListModel
{
    Q_OBJECT
    Q_ENUMS(AlarmsRoles)

public:
    /// перечисление, определяющее доступные роли элементов модли
    enum AlarmsRoles {
        IdRole = Qt::UserRole + 1,  ///< роль индекса
        PriorityRole,               ///< роль приоритета
        StartTimeRole,              ///< роль времени начала тревоги
        EndTimeRole                 ///< роль времени конца тревоги
    };

    /// метод получения числа строк в модели.
    int rowCount(const QModelIndex & parent = QModelIndex()) const;

    /// метод получения данных модели
    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;

    /// метод вставки тревоги на необходимую позицию
    void insertAlarmAtPos(Alarm* alarm,int pos);

    /// метод удаления тревоги из списка
    void removeAlarmAtPos(int pos);

    /// конструктор
    explicit AlarmModel(QList<Alarm*> *_alarmList,QObject *parent = 0);

    QHash<int, QByteArray> roleNames() const;
private:

    /// список тревог данной модели
    QList<Alarm*> *alarmList;


};





#endif // AlarmModel_H
