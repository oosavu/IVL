#ifndef ALARM_H
#define ALARM_H

#include <QObject>
#include <QDebug>
#include <QDateTime>
#include <QDataStream>


#include "alarm_id.h"

/**
 * Структура, описывающая тревогу.
 * Основные управляющие поля - isOpened и isWatched
 */

struct Alarm
{
    /// Флаг открытой тревоги.
    /// @value true если тревога открыта
    /// @value false иначе
    bool isOpened;
    /// Флаг просмотренности  тревоги.
    /// @value true если тревога просмотренна
    /// @value false иначе
    bool isWatched;
    /// индекс хранения в буфер тревог
    quint16 bufferIndex;
    /// ID тревоги
    AlarmId::Ids alarmID;
    /// приоритет тревоги
    AlarmId::Priorities alarmPriority;
    /// дата открытия
    QDateTime startTime;
    /// дата закрытия
    QDateTime endTime;
    /// Конструктор тревоги. Задаётся только alarmID. Остальные параметры задаются следующим образом:
    /// isOpened - true
    /// isWatched - true
    /// alarmPriority - сделать TODO
    /// startTime  = endTime = текущее время
    Alarm(AlarmId::Ids _alarmID = AlarmId::AlarmAR2);
    /// конвертирует поля тревоги в строку для удобства отладки
    QString toString();
    /// конвертирует тревогу в последовательность байт для сохранения в ПЗУ
    QByteArray toByteArray();
    /// заполняет поля тревоги из строки байт
    void fromByteArray(const QByteArray &arr);
};

#endif // ALARM_H
