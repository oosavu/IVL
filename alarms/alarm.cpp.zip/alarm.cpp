#include "alarm.h"

Alarm::Alarm(AlarmId::Ids _alarmID)
{
    alarmID = _alarmID;
    //TODO продумать как правильно
    if(int(alarmID)<3)    alarmPriority = AlarmId::High;
    else if(int(alarmID)<5)    alarmPriority = AlarmId::Mid;
    else   alarmPriority = AlarmId::Low;
    startTime = QDateTime::currentDateTime();
    endTime = QDateTime::currentDateTime();
    isOpened = true;
    isWatched = false;
    bufferIndex = 0;
}

QString Alarm::toString()
{
    return  QString("id: ")+ QString::number(alarmID) +\
            QString(" prior: ") + QString::number(alarmPriority) +\
            QString(" isOpened: ") + QString::number(isOpened) +\
            QString(" isWatched: ") + QString::number(isWatched) +\
            QString(" bufferIndex: ") + QString::number(bufferIndex) +\
            QString(" start: ") + startTime.toString("ss:mm:hh:dd:MM:yyyy")+\
            QString(" end: ") + endTime.toString("ss:mm:hh:dd:MM:yyyy");
}

QByteArray Alarm::toByteArray()
{
    QByteArray res;
    res.append((char*)&alarmID,2);
    res.append((char*)&alarmPriority,1);
    res.append((char*)&isOpened,1);
    res.append((char*)&isWatched,1);
    res.append(startTime.toString("ss:mm:hh:dd:MM:yyyy").toLatin1());
    res.append(endTime.toString("ss:mm:hh:dd:MM:yyyy").toLatin1());

    return res;
}

void Alarm::fromByteArray(const QByteArray &arr)
{
    QDataStream stream(arr);
    stream.readRawData((char*)&alarmID,2);
    stream.readRawData((char*)&alarmPriority,1);
    stream.readRawData((char*)&isOpened,1);
    stream.readRawData((char*)&isWatched,1);
    char temp[19];
    stream.readRawData(temp,19);
    startTime = QDateTime::fromString(temp,"ss:mm:hh:dd:MM:yyyy");
    endTime = QDateTime::fromString(temp,"ss:mm:hh:dd:MM:yyyy");
}
