#include "alarmmanager.h"
//#include "alarmmodel.h"
#include <QQmlContext>

AlarmManager* AlarmManager::_self = 0;

AlarmManager::AlarmManager(QObject *parent) :
    QObject(parent)
{
    alarmFile.setFileName("alarms.bin");
    if(!alarmFile.exists())
    {
        Alarm tempAlarm;
        tempAlarm.isOpened = false;
        tempAlarm.isWatched = true;
        quint16 tempTail = 0, tempHead = 0;
        if(alarmFile.open(QIODevice::ReadWrite)){

            alarmFile.write((char*)&tempHead,2);
            alarmFile.write((char*)&tempTail,2);
            for(int i = 0; i < ALARM_BUFER_SIZE; i++)
            {
                alarmFile.write(tempAlarm.toByteArray());
            }
            alarmFile.close();
        }
    }

    if(alarmFile.open(QIODevice::ReadWrite))
    {
        alarmFile.seek(0);
        alarmFile.read((char*)&head, 2);
        alarmFile.read((char*)&tail, 2);

        int size;
        if(head>tail)
            size = head - tail;
        else if (head == tail)
            size = 0;
        else
            size = head - tail + ALARM_BUFER_SIZE;
        //TODO некорректные хвосты

        for(int i = 0; i < size; i++)
        {
            int j = (tail + i + 1)%ALARM_BUFER_SIZE;

            Alarm* tempAlarm = new Alarm();
            tempAlarm->bufferIndex = j;
            alarmFile.seek(2+2+(5 +19*2)*j );
            tempAlarm->fromByteArray(alarmFile.read(42));

            alarms.append(tempAlarm);

            if(!tempAlarm->isWatched)
            {
                unwatchedAlarms.append(tempAlarm);
            }
        }
    }
    alarmmodelAll = new AlarmModel(&alarms);
    alarmmodelUnwatched = new AlarmModel(&unwatchedAlarms);
    alarmmodelCurrent = new AlarmModel(&currentAlarms);
    avilableMainAlarm = false;
    mainAlarm = 0;
}

AlarmManager *AlarmManager::instance()
{
    if(_self == 0)
        _self = new AlarmManager();
    return _self;
}

void AlarmManager::setAllAlarmsWatched()
{
    for(int i =0; i < unwatchedAlarms.size(); i++)
    {
        unwatchedAlarms.at(i)->isWatched = false;
        alarmFile.seek(4 + 43*unwatchedAlarms.at(i)->bufferIndex);
        alarmFile.write(unwatchedAlarms.at(i)->toByteArray());

    }
    int uA = unwatchedAlarms.size();
    for(int i =0; i < uA; i++)
        alarmmodelUnwatched->removeAlarmAtPos(0);
    //unwatchedAlarms.clear();
}

void AlarmManager::freeAlarms()
{
    head = 0;
    tail = 0;
    alarmFile.seek(0);
    alarmFile.write((char*)&head,2);
    alarmFile.write((char*)&tail,2);
}

void AlarmManager::bindContext(QQmlContext *ctx)
{
    ctx->setContextProperty("alarmModelAll",alarmmodelAll);
    ctx->setContextProperty("alarmmodelUnwatched",alarmmodelUnwatched);
    ctx->setContextProperty("alarmmodelCurrent",alarmmodelCurrent);
}

AlarmId::Ids AlarmManager::getMainAlarm() const
{
    if (mainAlarm) return mainAlarm->alarmID;
    else return AlarmId::AlarmAR1;
}

AlarmId::Priorities AlarmManager::getMainPriority() const
{
    if (mainAlarm) return mainAlarm->alarmPriority;
    else return AlarmId::Low;
}

QDateTime AlarmManager::getMainDataTime() const
{
    if (mainAlarm) return mainAlarm->startTime;
    else return QDateTime();
}

bool AlarmManager::getMainAvilablity() const
{
    return avilableMainAlarm;
}


bool AlarmManager::openAlarm(AlarmId::Ids id)
{
    //проверка, есть ли среди активных
    foreach(Alarm* alarm, currentAlarms)
    {
        if(alarm->alarmID == id)
        {
            qDebug() << "alarm " << id << " alredy opened!";
            return false;
        }
    }

    //при необходимости надо удалить хвостовой элемент
    head++;
    if(head >= ALARM_BUFER_SIZE) head = 0;
    if(tail == head)
    {
        tail++;
        if(tail >= ALARM_BUFER_SIZE) tail = 0;
        for(int i = 0; i < unwatchedAlarms.size(); i ++)
            if(unwatchedAlarms[i]->bufferIndex == tail)
            {
                alarmmodelUnwatched->removeAlarmAtPos(i);
                break;
            }
        for(int i = 0; i < currentAlarms.size(); i ++)
            if(currentAlarms[i]->bufferIndex == tail)
            {
                alarmmodelCurrent->removeAlarmAtPos(i);
                break;
            }
        for(int i = 0; i < alarms.size(); i ++)
            if(alarms[i]->bufferIndex == tail)
            {
                Alarm* temp = alarms.at(i);
                alarmmodelAll->removeAlarmAtPos(i);
                delete temp;
                break;
            }
    }

    //добавление в списки
    Alarm* alarm = new Alarm(id);
    alarm->bufferIndex = head;
    alarmmodelAll->insertAlarmAtPos(alarm,alarms.size());
    alarmmodelCurrent->insertAlarmAtPos(alarm,currentAlarms.size());
    //сохранение в файл
    alarmFile.seek(0);
    alarmFile.write((char*)&head,2);
    alarmFile.write((char*)&tail,2);
    alarmFile.seek(4 + 43*head);
    alarmFile.write(alarm->toByteArray());

    //проверка главной тревоги
    if (avilableMainAlarm == false)
    {
        mainAlarm = alarm;
        avilableMainAlarm = true;
        emit mainAlarmChanged();
    }
    return true;
}

bool AlarmManager::closeAlarm(AlarmId::Ids id)
{
    for(int i = 0; i< currentAlarms.size(); i++)
    {
        if(currentAlarms[i]->alarmID == id)
        {
            qDebug()<< "close id:" + QString::number(id);
            Alarm* alarm = currentAlarms.at(i);
            alarm->isOpened = false;
            alarmmodelCurrent->removeAlarmAtPos(i);
            alarmmodelUnwatched->insertAlarmAtPos(alarm,unwatchedAlarms.size());
            if(currentAlarms.size() == 0)
            {
                avilableMainAlarm = false;
                emit mainAlarmChanged();
            }
            else if(mainAlarm->alarmID == alarm->alarmID){
                mainAlarm = currentAlarms[0];
                emit mainAlarmChanged();
            }
            return true;
        }
    }
    return false;
}

bool AlarmManager::serviceAlarms(AlarmId::Ids id, bool needToOpen)
{
    if(needToOpen) return openAlarm(id);
    else return closeAlarm(id);
}

