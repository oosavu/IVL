#include "alarmmodel.h"
//#include "alarmmanager.h"

AlarmModel::AlarmModel(QList<Alarm *> *_alarmList, QObject *parent) :
    QAbstractListModel(parent)
{



    alarmList = _alarmList;
    //reset();
}

QHash<int, QByteArray> AlarmModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[IdRole] = "alarmId";
    roles[PriorityRole] = "alarmPriority";
    roles[StartTimeRole] = "alarmStartTime";
    roles[EndTimeRole] = "alarmEndTime";
    return roles;
}

int AlarmModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
   // qDebug()<<"rowCount: "<<alarmList.size();
    return alarmList->size();
}

QVariant AlarmModel::data(const QModelIndex &index, int role) const
{
//    qDebug()<<"data index: "<<index.row()<< " iz " << alarmList.size();
//    qDebug()<<"data role: "<<role;
    if (index.row() < 0 || index.row() >= alarmList->size())
        return QVariant();

    const Alarm* currentAlarm = alarmList->at(index.row());
    if (role == IdRole){
        return currentAlarm->alarmID;
        qDebug()<<"id: "<< currentAlarm->alarmID;
    }
    else if (role == PriorityRole)
        return currentAlarm->alarmPriority;
    else if (role == EndTimeRole)
        return currentAlarm->startTime;
    else if (role == EndTimeRole)
        return currentAlarm->endTime;
    return QVariant();

}

void AlarmModel::insertAlarmAtPos(Alarm *alarm, int pos)
{
    //pos = 2;
    beginInsertRows(QModelIndex(), pos, pos);
        alarmList->insert(pos, alarm);
    endInsertRows();
}

void AlarmModel::removeAlarmAtPos(int pos)
{
    //pos = 2;
    beginRemoveRows(QModelIndex(), pos, pos);
        alarmList->removeAt(pos);
    endRemoveRows();
}



//void AlarmModel::onAlarmsChanged(int r)
//{

//    qDebug()<<"onAlarmsChanged: ";
//    //reset();
//    beginInsertRows(QModelIndex(), r, r);
//    //emit (QModelIndex(),QModelIndex());
//    endInsertRows();
//}


//AlarmModel *AlarmModel::instance()
//{
//    if (_self == 0) _self = new AlarmModel();
//    return _self;
//}
