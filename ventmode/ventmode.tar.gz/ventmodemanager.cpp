#include "ventmodemanager.h"

//опеределение статических переменных
VentModeManager* VentModeManager::_self = 0;

void VentModeManager::setTrueVentMode(VentModeManager::ventmodes arg)
{
    if (m_trueVentMode != arg) {
        m_trueVentMode = arg;
        emit trueVentModeChanged(arg);
    }
}

void VentModeManager::setVentMode(VentModeManager::ventmodes arg)
{
    if (m_ventMode != arg) {
        m_ventMode = arg;

        QList<ParamRule*>* currentRulesScope = ventModeRulesMap[arg];

//        foreach(ParamRule* pr, *currentRulesScope)
//        {
//            pr->vdp->setErrorLevel(ErroredParameter::ErrorNo);
//            pr->vdp->setMaxValue(pr->maxAdult);
//            pr->vdp->setMinValue(pr->minAdult);
//            pr->vdp->dependConflicts = pr->dependConflicts;
//            foreach(DependenceParamRule* dpr, *(pr->dpList))
//            {
//                dpr->depParam->setAvilability(true);
//                dpr->depParam->calculateFunc = dpr->calculateProcedure;
//                dpr->depParam->setMin(dpr->minAdult);
//                dpr->depParam->setMax(dpr->maxAdult);
//            }

//        }
        emit ventModeChanged();

    }
}



VentModeManager *VentModeManager::instance()
{
    if(!_self)
    {
        _self = new VentModeManager();
    }
    return _self;
}

void VentModeManager::bindContext(QQmlContext *ctx)
{
    ctx->setContextProperty("dpFiO2"         , &dpFiO2         );
    ctx->setContextProperty("dpPMax"         , &dpPMax         );
    ctx->setContextProperty("dpRB"           , &dpRB           );
    ctx->setContextProperty("dpPEEP"         , &dpPEEP         );
    ctx->setContextProperty("dpVInsp"        , &dpVInsp        );
    ctx->setContextProperty("dpTInsp"        , &dpTInsp        );
    ctx->setContextProperty("dpPlato"        , &dpPlato        );
    ctx->setContextProperty("dpFormFlow"     , &dpFormFlow     );
    ctx->setContextProperty("dpPTrig"        , &dpPTrig        );
    ctx->setContextProperty("dpFTrig"        , &dpFTrig        );
    ctx->setContextProperty("dpPSupp"        , &dpPSupp        );
    ctx->setContextProperty("dpPInsp"        , &dpPInsp        );
    ctx->setContextProperty("dpPHigh"        , &dpPHigh        );
    ctx->setContextProperty("dpPLow"         , &dpPLow         );
    ctx->setContextProperty("dpTHigh"        , &dpTHigh        );
    ctx->setContextProperty("dpTLow"         , &dpTLow         );
    ctx->setContextProperty("dpPramp"        , &dpPramp        );
    ctx->setContextProperty("dpFSupp"        , &dpFSupp        );
    ctx->setContextProperty("dpTrigWnd"      , &dpTrigWnd      );
    ctx->setContextProperty("bpApneaRegime"  , &bpApneaRegime  );
    ctx->setContextProperty("dpApneaWeight"  , &dpApneaWeight  );
    ctx->setContextProperty("dpApneaV"       , &dpApneaV       );
    ctx->setContextProperty("dpApneaPi"      , &dpApneaPi      );
    ctx->setContextProperty("dpApneaRB"      , &dpApneaRB      );
    ctx->setContextProperty("dpApneaT"       , &dpApneaT       );
    ctx->setContextProperty("edpPramp"       , &edpPramp       );
    ctx->setContextProperty("edpComplPeriod" , &edpComplPeriod );
    ctx->setContextProperty("edpFEnd"        , &edpFEnd        );
    ctx->setContextProperty("edpDisconSens"  , &edpDisconSens  );
    ctx->setContextProperty("edpPmaxLim"     , &edpPmaxLim     );
    ctx->setContextProperty("edpTiLim"       , &edpTiLim       );
    ctx->setContextProperty("ebpSigh"        , &ebpSigh        );
    ctx->setContextProperty("bpAge"          , &bpAge          );
    ctx->setContextProperty("bpTrigMode"     , &bpTrigMode     );
    ctx->setContextProperty("bdpTiTc"        , &bdpTiTc        );
    ctx->setContextProperty("bdpFlow"        , &bdpFlow        );
    ctx->setContextProperty("bdpFlowMax"     , &bdpFlowMax     );
    ctx->setContextProperty("bdpTexp"        , &bdpTexp        );
    ctx->setContextProperty("bdpTsense"      , &bdpTsense      );
    ctx->setContextProperty("bdpTplato"      , &bdpTplato      );
    ctx->setContextProperty("bdpMV"          , &bdpMV          );
    ctx->setContextProperty("bdpPTrig"       , &bdpPTrig       );
    ctx->setContextProperty("bdpFTrig"       , &bdpFTrig       );
    ctx->setContextProperty("bdpTramp"       , &bdpTramp       );
}

void VentModeManager::setAvilableChangeMode(bool newAC)
{
        m_avilablityChangeMode = newAC;
        emit avilableChangeModeChanged();
}

void VentModeManager::acceptModeVent()
{
    bool mayAccept = true;
    if(mayAccept)
    {
        CanMessage par1(canId::kivl::ID_PAR1_CIVL,8);
        par1.setBit(0,0,7);     //бит7: =1/0 детский/взрослый режим
        par1.setBit(0,0,6);     //бит6: =0 нет режима "вздох", =1 режим "вздох" (через 50 циклов)
        par1.setBit(0,0,5);     //бит5: =0 поток прямоугольный, =1 поток убывающий
        par1.setBit(0,0,4);     //бит4: =0 активен триггер по давлению, =1 активен триггер по потоку
        //par1.setEnum(0,4,0,0);  //биты3..0: режим ИВЛ
        par1.setUInt8(1,1);     //Байт1: величина ПДКВ [см вод.ст.]. В режиме BiSTEP это есть Plow.
        par1.setUInt8(1,2);     //Байт2: чувствительность триггера по давлению [мм вод. ст.] (до 200 мм, другие значения ограничиваются 200 мм вод. ст.)
        par1.setUInt8(1,3);     //Байт3: чувствительность триггера по потоку [0.1 л/мин]
        par1.setUInt16(1000,4); //Байты4,5: время вдоха [мс]
        par1.setUInt16(1000,6); //Байты6,7: время выдоха [мс]

        CanMessage par2(canId::kivl::ID_PAR2_CIVL,8);
        par2.setUInt16(300,0);  //Байты0,1: объём вдоха [мл] (200..2000)
        par2.setUInt8(20,2);    //Байт2: длительность плато [%] (0..40)
        par2.setUInt8(0,3);     //Байт3: величина PS над уровнем ПДКВ [см вод.ст.] Используется в режимах SIMV/VC, SIMV/PC, CPAP, BiSTEP
        par2.setUInt8(40,4);    //Байт4: значение Pmax [см вод.ст.] (20..80)
        par2.setUInt8(45,5);    //Байт5: значение Pt [см вод.ст.] (Pressure Tidal, целевое давление вдоха) (5..80) Используется в режимах CMV/PCV, SIMV/PC, BiSTEP. В режиме BiSTEP это есть Phigh.
        par2.setUInt8(20,6);    //Байт6: триггерное окно (0..100%)
        par2.setUInt8(5,7);     //Байт7: триггер окончания вдоха [% от Finsp_max] для режимов отличных от НИВ [л/мин] для НИВ

        CanMessage par3(canId::kivl::ID_PAR3_CIVL,7);
        par3.setUInt16(300,0);  // Байты0,1: для режимов, отличных от НИВ - скорость нарастания давления 50..2000 [ммH2O/с], для режима НИВ - ускорение потока 10..100 [%].
        par3.setUInt8(1,2);     // Байт2: число, отвечающее за частоту выдачи пакета ID_WAVE_CIVL для отрисовки графиков. Частота выдачи равна 500/Байт, но не менее 15 Гц. Байт = 1..33, другие значения считаются равны 33 (15 Гц)
        par3.setUInt8(1,3);     // Байт3: поток поддержки [л/мин]
        par3.setUInt8(40,4);    // Байт4: чувствительность к дисконнекции [%]. Если в 3 подряд дыхательных циклах объём выдоха будет более чем на указанное число % меньше объёма вдоха, то будет продетектирована разгерметизация. 0% означает что объём выдоха может быть любым, без выработки тревоги "разгерметизация" по этому критерию. 100% означает, что отличие даже на 1 мл приведёт к тревоге. От 0 до 100%, остальные значения ограничиваются до 100%
        par3.setUInt8(3,5);     // Байт5: приращение deltaPEEP для манёвра раскрытия альвеол
        par3.setBit(0,6,0);     // Байт6: бит0: =1/0 -- вкл/выкл компенсацию утечки, только в CMV/VCV

        CanMessage apnea(canId::kivl::ID_PARAPNEA_CIVL,6);
        apnea.setUInt8(10,0);    //Байт0: частота вентиляции апноэ [вд/мин]
        apnea.setUInt8(30,1);    //Байт1: время детекции апноэ [с]
        apnea.setUInt16(2000,2); //Байты2,3: дыхательный объём при возникновении апноэ [мл]
        apnea.setUInt8(10,4);    //Байт4: целевое давление апноэ на вдохе при апноэ PCV типа [см вод.ст.]
        apnea.setUInt8(0,5);     //Байт5: =0/1 типа апноэ VCV/PCV

        CanMessage opt(canId::kivl::ID_OPT_CIVL,8);
        opt.setBit(1,3,3);
        opt.setBit(1,7,3);

        CanMessage kivlwork(canId::kivl::ID_MODE_CIVL,1);
        kivlwork.setUInt8(1,0);

        CanMessage mixwork(canId::mix::ID_MODE_MIX,1);
        mixwork.setUInt8(1,0);

        CanMessage fio2(canId::bu::ID_OXY,1);
        fio2.setUInt8(22,0);

        CanMessage power(canId::power2::ID_MODE_PWR,1);
        power.setBit(1,0,0);


        CanDevice::instance()->sendMessage(power);
        CanDevice::instance()->sendMessage(mixwork);
        CanDevice::instance()->sendMessage(fio2);
        CanDevice::instance()->sendMessage(apnea);
        CanDevice::instance()->sendMessage(opt);
        CanDevice::instance()->sendMessage(par1);
        CanDevice::instance()->sendMessage(par2);
        CanDevice::instance()->sendMessage(par3);
        CanDevice::instance()->sendMessage(kivlwork);
    }
}
void VentModeManager::cancelModeVent()
{

}

void VentModeManager::stopVent()
{
    CanMessage kivlwait(canId::kivl::ID_MODE_CIVL,1);
    kivlwait.setUInt8(0,0);
    CanDevice::instance()->sendMessage(kivlwait);

    CanMessage mixwait(canId::mix::ID_MODE_MIX,1);
    mixwait.setUInt8(0,0);
    CanDevice::instance()->sendMessage(mixwait);


    CanMessage power(canId::power2::ID_MODE_PWR,1);
    power.setBit(0,0,0);
    CanDevice::instance()->sendMessage(power);
}

void VentModeManager::canselAPNEA()
{
    if(getIsAPNEA())
    {
        //TODO код отправки сообщения о включении режима.
    }
}

void VentModeManager::acceptModeApnea()
{

}

void VentModeManager::cancelModeApnea()
{
}

bool VentModeManager::getIsAPNEA() const
{
    return m_isAPNEA;
}

void VentModeManager::setIsAPNEA(bool arg)
{
    if (m_isAPNEA != arg) {
        m_isAPNEA = arg;
        AlarmManager::instance()->serviceAlarms(AlarmId::AlarmApnea,m_isAPNEA);
        emit IsAPNEAChanged(arg);
    }
}

VentModeManager::ventmodes VentModeManager::getTrueVentMode() const
{
    return m_trueVentMode;
}

VentModeManager::VentModeManager(QObject *parent) :
    QObject(parent)
{
    initRules();
    ventModeRulesMap[CIVL_VENTMODE_CMV_VCV] = &params_CMVVCV;
    ventModeRulesMap[CIVL_VENTMODE_CMV_PCV] = &params_CMVPCV;
    dpPMax.attemptSetValue(15);
    setVentMode(CIVL_VENTMODE_CMV_VCV);
    setTrueVentMode(CIVL_VENTMODE_UNKNOWN);
    setAvilableChangeMode(true); // TODO озможно не надо здесь
    setIsAPNEA(false);
}






