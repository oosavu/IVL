#ifndef VENTMODETYPES_H
#define VENTMODETYPES_H

#include <QList>
#include "../types/parametersTypes.h"


class VentDependenceParameter;
class VentDigitParameter;

/**
 * Структура для описания поведения зависимого параметра. Определяет граничные значения и
 * указатель на функцию для его вычисления
 */
struct DependenceParamRule{
    /// минимум для детского режима
    qint32 minChild;
    /// минимум для взрослого режима
    qint32 minAdult;
    /// максимум для детского режима
    qint32 maxChild;
    /// максимум для взрослого режима
    qint32 maxAdult;
    /// функция для вычисления значения параметра
    qint32 (*calculateProcedure)();
    ///указатель на зависимый параметр
    VentDependenceParameter* depParam;

    /**
     * @brief DependenceParamRule
     * @param dp указатель на вычисляемый параметр, для которого предназначено данное правило
     * @param mC минимум для детского режима
     * @param mA минимум для взрослого режима
     * @param MC максимум для детского режима
     * @param MA максимум для взрослого режима
     * @param func функция вычисления параметра
     */
    DependenceParamRule(VentDependenceParameter* dp , qint32 mC, qint32 mA, qint32 MC, qint32 MA, qint32 (*func)())
    {
        Q_ASSERT(mC < MC);
        Q_ASSERT(mA < MA);
        Q_ASSERT(func != 0);
        minChild =mC; minAdult = mA; maxChild = MC; maxAdult = MA;
        calculateProcedure = func;
        depParam = dp;
    }
};

/**
 * структура конфликта между задаваемыми параметрами.
 */
struct Conflict{
    /// приоритет конфликта. Определяет, какой уровень ошибки будет присвоен реагирующим параметрам.
    ErroredParameter::errorLevels errorPriority;
    /// указатель на функцию конфликта
    bool (*conflictFunction)();
    /// зависящие от конфликта параметры
    QList<VentDigitParameter*> *dependParams;
    /**
     * @brief конструктор
     * @param el уровень ошибки, которая присваиваится параметрам в случае возникновения конфликта
     * @param func функция вычисления конфликта
     * @param _dependParams список параметров, которые станут ошибочными при возникновении данного конфликта
     */
    Conflict(ErroredParameter::errorLevels el, bool (*func)(), QList<VentDigitParameter*> *_dependParams = 0)
    {
        Q_ASSERT(func != 0);
        errorPriority = el;
        conflictFunction = func;
        dependParams = _dependParams;
    }
};

/**
 * Структура для  описания поведения задаваемого параметра.
 * указатель на функцию для его вычисления
 */
struct ParamRule{
    /// минимум для детского режима
    qint32 minChild;
    /// минимум для взрослого режима
    qint32 minAdult;
    /// максимум для детского режима
    qint32 maxChild;
    /// максимум для взрослого режима
    qint32 maxAdult;
    /// список зависимых вычисляемых параметров
    QList<DependenceParamRule*> *dpList;
    /// список зависимых конфликтов
    QList<Conflict*> *dependConflicts;

    VentDigitParameter* vdp;

    /**
     * @brief ParamRule конструктор
     * @param _vdp указатель на параметр, к которому применяется данное правило
     * @param mC  минимум для детского режима
     * @param mA  минимум для взрослого режима
     * @param MC  максимум для детского режима
     * @param MA  максимум для взрослого режима
     * @param _dpList список зависимых от данного параметра вычисляемых параметров
     * @param _dependConflicts список конфликтов, которые могут возникнуть при редактировании данного параметра
     */
    ParamRule(VentDigitParameter* _vdp,
              qint32 mC = 10, qint32 mA = 11, qint32 MC = 23, qint32 MA = 24,
              QList<DependenceParamRule*> *_dpList = 0,
              QList<Conflict*> *_dependConflicts = 0)
    {
        Q_ASSERT(mC < MC);
        Q_ASSERT(mA < MA);
        minChild =mC; minAdult = mA; maxChild = MC; maxAdult = MA;
        dpList = _dpList;
        dependConflicts = _dependConflicts;
    }
};



class VentDependenceParameter: public NonEditableBoundedDigitParameter
{
public:
    qint32 (*calculateFunc)();

    /**
     * @brief VentDependenceParameter конструктор
     * @param startValue стартовое значение параметра
     * @param startAvilability стартовое значение "доступности"
     * @param startMin стартовое значение минимума
     * @param startMax стартовое значение максимума
     * @param parent указатель на родителя
     */
    VentDependenceParameter(qint32 startValue = 23,
                            bool startAvilability = true,
                            quint32 startMin = 12,
                            quint32 startMax = 24,
                            qint32 (*func)() = 0,
                            QObject* parent = 0):
        NonEditableBoundedDigitParameter(startValue, startAvilability, startMin, startMax, parent)
    {
        calculateFunc = func;
    }

public slots:
    void calculateValue()
    {
        Q_ASSERT(calculateFunc != 0);
        setValue(calculateFunc());

    }
};



class VentDigitParameter: public DigitParameter
{
public:
    /**
     * @brief VentDigitParameter конструктор
     * @param initValue стартовое значение
     * @param initMinValue стартовое минимальное значение
     * @param initMaxValue стартовое максимальное значение
     * @param _dpList список зависимых параметров, которые изменяются при изменении данного параметра (у них вызывается функция пересчёта)
     * @param _dependConflicts список конфликтов, которые могут возникнуть при изменении данного параметра
     * @param parent указатель на родителя
     */
    VentDigitParameter(qint32 initValue = 10,
                       qint32 initMinValue = 0,
                       qint32 initMaxValue = 20,
                       QList<VentDependenceParameter*> *_dpList = 0,
                       QList<Conflict*> *_dependConflicts = 0,
                       QObject *parent = 0):
        DigitParameter(initValue,initMinValue,initMaxValue, parent)
    {
        dpList = _dpList;
        dependConflicts = _dependConflicts;
    }

    QList<VentDependenceParameter*> *dpList;
    QList<Conflict*> *dependConflicts;

    void attemptSetValue(qint32 arg)
    {
        DigitParameter::attemptSetValue(arg);
        if(dpList != 0)
            foreach(VentDependenceParameter* par, *dpList)
                par->calculateValue();
        if(dependConflicts != 0)
            foreach(Conflict* par, *dependConflicts)
            {
                if(par->conflictFunction())
                    foreach(VentDigitParameter* vdp, *(par->dependParams))
                        vdp->setErrorLevel(par->errorPriority);
            }
    }
};



#endif // VENTMODETYPES_H
