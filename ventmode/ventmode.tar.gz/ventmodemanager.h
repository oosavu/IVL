#ifndef MODEMANAGER_H
#define MODEMANAGER_H

#include <QObject>
#include <QQmlContext>
#include "../alarms/alarmmanager.h"
#include "../CAN/candevice.h"
#include "ventmodetypes.h"


class VentModeManager;
//enum VentModeManager::ventmodes;


extern VentDigitParameter dpFiO2     ;
extern VentDigitParameter dpPMax     ;
extern VentDigitParameter dpRB       ;
extern VentDigitParameter dpPEEP     ;
extern VentDigitParameter dpVInsp    ;
extern VentDigitParameter dpTInsp    ;
extern VentDigitParameter dpPlato    ;
extern VentDigitParameter dpFormFlow ;
extern VentDigitParameter dpPTrig    ;
extern VentDigitParameter dpFTrig    ;
extern VentDigitParameter dpPSupp    ;
extern VentDigitParameter dpPInsp    ;
extern VentDigitParameter dpPHigh    ;
extern VentDigitParameter dpPLow     ;
extern VentDigitParameter dpTHigh    ;
extern VentDigitParameter dpTLow     ;
extern VentDigitParameter dpPramp    ;
extern VentDigitParameter dpFSupp    ;
extern VentDigitParameter dpTrigWnd  ;
extern BoolParameter  bpApneaRegime ;
extern DigitParameter dpApneaWeight ;
extern DigitParameter dpApneaV      ;
extern DigitParameter dpApneaPi     ;
extern DigitParameter dpApneaRB     ;
extern DigitParameter dpApneaT      ;
extern EditableDigitParameter edpPramp        ;
extern EditableDigitParameter edpComplPeriod  ;
extern EditableDigitParameter edpFEnd         ;
extern EditableDigitParameter edpDisconSens   ;
extern EditableDigitParameter edpPmaxLim      ;
extern EditableDigitParameter edpTiLim        ;
extern EditableBoolParameter  ebpSigh         ;
extern BoolParameter          bpAge           ; //true = child
extern BoolParameter          bpTrigMode      ; //true = po potoku
extern VentDependenceParameter  bdpTiTc    ;
extern VentDependenceParameter  bdpFlow    ;
extern VentDependenceParameter  bdpFlowMax ;
extern VentDependenceParameter  bdpTexp    ;
extern VentDependenceParameter  bdpTsense  ;
extern VentDependenceParameter  bdpTplato  ;
extern VentDependenceParameter  bdpMV      ;
extern VentDependenceParameter  bdpPTrig   ;
extern VentDependenceParameter  bdpFTrig   ;
extern VentDependenceParameter  bdpTramp   ;
extern QList<ParamRule*> params_CMVVCV;
extern QList<ParamRule*> params_CMVPCV;
extern void initRules();




/**
 * класс отвечающий за смену режимов вентиляции.
 * Для QML расшаривает текущий режим, настраевые параметры,
 * редко измеряемые параметры режимов.
 * TODO продумать общение данного класса с С++. формирование пакетов для кивл в нем ли делать?
 */
class VentModeManager : public QObject
{
    Q_OBJECT

    /// Свойство текущего режима вентиляции. Всегда отображает текущее значение вентиляции (то которое в кивле)
    /// предназначено для отображения в левом верхнем углу.
    Q_PROPERTY(ventmodes trueVentMode READ getTrueVentMode NOTIFY trueVentModeChanged)
    /// Свойство редактируемого режима вентиляции.В большинсве случаев совпадает с trueVentMode,
    /// но при задании нового режима  - нет. нужно для отображения при диалоге изменения режима.
    Q_PROPERTY(ventmodes ventMode READ getVentMode WRITE setVentMode NOTIFY ventModeChanged)
    /// свойство доступности изменения  режима. истенно в случае если все вычисляемые и задаваевыемые
    /// параметры не ошибочны.
    Q_PROPERTY(bool avilableChangeMode READ getAvilableChangeMode NOTIFY avilableChangeModeChanged)
    /// Признак наличия АПНОЭ. формируется/снимается из С++, либо с помощью функции cancelApnea из QML.
    Q_PROPERTY(bool isAPNEA READ getIsAPNEA NOTIFY IsAPNEAChanged)
public:
    Q_ENUMS(ventmodes)
    /// перечисление режимов вентиляции, представленных пользователю.
    enum  ventmodes{
        CIVL_VENTMODE_CMV_VCV = 0,     /* CMV/VCV */
        CIVL_VENTMODE_CMV_PCV,     /* CMV/PCV */
        CIVL_VENTMODE_SIMV_PC,     /* SIMV/PCV+PS+apnea */
        CIVL_VENTMODE_SIMV_VC,     /* SIMV/VCV+PS+apnea */
        CIVL_VENTMODE_CPAP,        /* CPAP+PS+apnea */
        CIVL_VENTMODE_BISTEP,      /* BiSTEP+PS+apnea */
        CIVL_VENTMODE_NIV,         /* NIV */
        CIVL_VENTMODE_ISV,         /* ISV */
        CIVL_VENTMODE_PCV_VG,      /* PCV-VG */
        CIVL_VENTMODE_SIMV_DC,     /* SIMV/DC */
        CIVL_VENTMODE_APNEA,       /* Apnea */
        CIVL_VENTMODE_UNKNOWN      /* Неизвестный режим вентиляции */
    };
    /// функция получения ссылки на объект. необходима для реализации паттерна синглтон
    /// @return указатель на объект
    static VentModeManager* instance();
    /// функция регистрации переменных для контекста QML
    /// @param ctx контекст, в котором необходимо зарегистрировать необходимые параметры
    void bindContext(QQmlContext* ctx);
    /// функция получения текущего редактируемого режима вентиляции. необходимо для свойства ventMode
    /// @return текущий режим вентиляции
    ventmodes getVentMode(){
        //qDebug()<<"getting ventmode: "<< m_ventMode;
        return m_ventMode;}
    /// функция возвращает значение возможности изменения режима
    /// @return возможность изменения режима
    bool getAvilableChangeMode(){return m_avilablityChangeMode;}
    /// устанавливает свойство редактируемости
    /// @param newAC новое значение редактируемости режима
    void setAvilableChangeMode(bool newAC);
    /// Функция принятия нового редима вентиляции. Устанавливает все значения задаваемых параметров на текущие позиции
    /// изменяет текущий режим и посылает сообщения (TODO просто подготавливает) на кивл.
    Q_INVOKABLE void acceptModeVent();
    /// Функция отменяет все изменения текущего режима и устанавливает все задаваемые параметры
    /// равными действительным параметрам  (вызывается при нажатии кнопки отмена)
    Q_INVOKABLE void cancelModeVent();

    Q_INVOKABLE void stopVent();

    /// Функция выхода из режима АПНОЭ.
    Q_INVOKABLE void canselAPNEA();
    /// метод подтверждения изменения параметров АПОНОЭ. ставит параметры апноэ в текущие и отмсылает пакет в КИВЛ.
    Q_INVOKABLE void acceptModeApnea();
    /// метод отмены изменений параметров АПНОЭ. возвращает все параметры на место.
    Q_INVOKABLE void cancelModeApnea();
    /// Функция для получения значения для свойства isAPNEA
    bool getIsAPNEA() const;
    /// Функция для установки значения для свойства isAPNEA.
    /// @param arg = true для установки, false для снятия
    void setIsAPNEA(bool arg);
    /// Функция для получения значения свойства trueVentMode.
    /// @return значение текущего активного режима
    ventmodes getTrueVentMode() const;
private:
    /// указатель на себя
    static VentModeManager* _self;
    /// конструктор
    VentModeManager(QObject *parent = 0);
    /// текущая доступность изменения режима
    bool m_avilablityChangeMode;
    /// признак наличия АПНОЭ
    bool m_isAPNEA;
    /// переменная для хранения значения свойства текущего истинного режима
    ventmodes m_trueVentMode;
    /// переменная для хранения значения свойства текущего редактируемого режима
    ventmodes m_ventMode;
    /// словарь массивов правил для режимов вентиляции
    QMap<VentModeManager::ventmodes,QList<ParamRule*>*> ventModeRulesMap;



public slots:
    /// функция установки текущего истинного режиима вентиляции. необходимо для свойства trueVentMode
    /// @param newVentMode новый режим вентиляции
    void setTrueVentMode(ventmodes arg);
    /// функция установки текущего редактируемого режиима вентиляции. необходимо для свойства ventMode
    /// @param newVentMode новый режим вентиляции
    void setVentMode(ventmodes arg);


signals:
    /// сигнал, высылаемый при изменении доступности редактирования режима вентиляции
    void avilableChangeModeChanged();
    /// сигнал, высылаемый в случае изменения статуса режима АПНОЭ
    void IsAPNEAChanged(bool arg);
    /// сигнал высылаемый в случае изменения текущего режима вентиляции
    void trueVentModeChanged(ventmodes arg);
    /// сигнал, высылаемый в случае изменения  редактируемого режима вентиляции
    void ventModeChanged();
};


#endif // MODEMANAGER_H
