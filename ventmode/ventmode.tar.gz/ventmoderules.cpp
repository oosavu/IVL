#include "ventmoderules.h"

qint32 calcTExp()
{
    return 60000/dpRB.getValue() -  dpTInsp.getValue();
}
qint32 calcTSense()
{
    qint32 val = 60000/dpRB.getValue() -  dpTInsp.getValue();
    val =  dpTrigWnd.getValue()*(val - 200)/100;
    return val;
}
qint32 calcTPlato()
{
     return dpPlato.getValue();
}
qint32 calcTiTc()
{
     return dpRB.getValue()* dpTInsp.getValue()/600;
}
qint32 calcMV()
{
     return dpRB.getValue()* dpVInsp.getValue()/100;
}
qint32 calcFlow1()
{
    if(dpTInsp.getValue() - dpPlato.getValue() != 0)
        return 600* dpVInsp.getValue()/( dpTInsp.getValue() - dpPlato.getValue());
    else return 600* dpVInsp.getValue()/(1);
}
qint32 calcFlow2()
{
     return 600* dpVInsp.getValue()/( dpTInsp.getValue());
}
qint32 calcFlowMax1()
{
    if(dpTInsp.getValue() - dpPlato.getValue() != 0)
        return 1200* dpVInsp.getValue()/( dpTInsp.getValue() - dpPlato.getValue()) - 30;
    return 1200* dpVInsp.getValue()/(1) - 30;
}
qint32 calcFlowMax2()
{
     return 1200* dpVInsp.getValue()/( dpTInsp.getValue()) - 30;
}
qint32 calcTramp()
{
     return dpPInsp.getValue()/( dpPramp.getValue());
}
qint32 calcPtrig()
{
     return dpPTrig.getValue();
}
qint32 calcFtrig()
{
     return dpFTrig.getValue();
}

//////////////////////////////////////////////////////////////////////

bool conflict_HightFlow()
{
    return (bdpFlow.getErrorLevel() == ErroredParameter::Error2 ); //Error2 означает превышение верхнего предела
}
bool conflict_FormFlow_FlowMax()
{
    return (dpFormFlow.getValue() == 1 && bdpFlowMax.getErrorLevel() == ErroredParameter::Error2); // 1 == треугольная TODO сделать для этого перечисление
}
bool conflict_Flow_Plato()
{
    return (bdpFlow.getErrorLevel() == ErroredParameter::Error2 && dpPlato.getValue() > 0); //Error2 означает превышение верхнего предела
}
bool conflict_Plato_TInsp()
{
    return dpPlato.getValue()>7*dpTInsp.getValue()/10;
}
bool conflict_RB_TInsp()
{
    if(dpRB.getValue() == 0 ) return false;
    return 60000/dpRB.getValue() - dpTInsp.getValue() < (bpAge.getValue()? 200 : 300);
}
bool conflict_TrigMode_PTrig_PEEP()
{
    return (bpTrigMode.getValue() == 0 && dpPTrig.getValue() > dpPEEP.getValue()*10);
}
bool conflict_FTrig_FSupp()
{
    return (dpFTrig.getValue() > dpFSupp.getValue());
}
bool conflict_PEEP_PMax_CMVVCV()
{
    return (dpPEEP.getValue() + 10 > dpPMax.getValue());
}
bool conflict_PEEP_PMax_CMVPCV()
{
    return (dpPEEP.getValue() + 5 > dpPMax.getValue());
}
bool conflict_PEEP_PMax_PSupp()
{
    return (dpPEEP.getValue() + dpPSupp.getValue() + 5 > dpPMax.getValue());
}
bool conflict_PEEP_PMax_PCV_VG()
{
    return (dpPEEP.getValue() + 15 > dpPMax.getValue());
}
bool conflict_Tsense()
{
    return (bdpTsense.getValue() < 0);
}
bool conflict_PInsp_PEEP_PMax()
{
    return dpPMax.getValue() < dpPEEP.getValue()+ dpPInsp.getValue() + 5;
}
bool conflict_HightPMax()
{
    return bpAge.getValue()?  dpPMax.getValue() >60: dpPMax.getValue()> 80;
}
bool conflict_Vapnea_RBapnea()
{
    return false;
    //TODO посмотреть подробнее про ф-ю AckApneaParamIsFlowInspOk
}
bool conflict_PHigh_PLow()
{
    return dpPHigh.getValue() < dpPLow.getValue();
}
bool conflict_PS_PLow()
{
    return dpPLow.getValue() + dpPSupp.getValue() > 75;
}
bool conflict_THigh_TLow()
{
    return dpTHigh.getValue() < dpTLow.getValue();
}

void initRules()
{
    dr_TExp     = new DependenceParamRule(&bdpTexp   ,   21, 21, 100, 100, calcTExp      );
    dr_TSense   = new DependenceParamRule(&bdpTsense ,   21, 21, 100, 100, calcTSense    );
    dr_TPlato   = new DependenceParamRule(&bdpTplato ,   21, 21, 100, 100, calcTPlato    );
    dr_TiTc     = new DependenceParamRule(&bdpTiTc   ,   21, 21, 100, 100, calcTiTc      );
    dr_MV       = new DependenceParamRule(&bdpMV     ,   21, 21, 100, 100, calcMV        );
    dr_Flow1    = new DependenceParamRule(&bdpFlow   ,   21, 21, 100, 100, calcFlow1     );
    dr_Flow2    = new DependenceParamRule(&bdpFlow   ,   21, 21, 100, 100, calcFlow2     );
    dr_FlowMax1 = new DependenceParamRule(&bdpFlow   ,   21, 21, 100, 100, calcFlowMax1  );
    dr_FlowMax2 = new DependenceParamRule(&bdpFlow   ,   21, 21, 100, 100, calcFlowMax2  );
    dr_Tramp    = new DependenceParamRule(&bdpTramp  ,   21, 21, 100, 100, calcTramp     );
    dr_PTrig    = new DependenceParamRule(&bdpPTrig  ,   21, 21, 100, 100, calcPtrig     );
    dr_FTrig    = new DependenceParamRule(&bdpFTrig  ,   21, 21, 100, 100, calcFtrig     );

    conf_HightFlow         = new Conflict(ErroredParameter::Error2, conflict_HightFlow          );
    conf_FormFlowFlowMax   = new Conflict(ErroredParameter::Error2, conflict_FormFlow_FlowMax   );
    conf_FlowPlato         = new Conflict(ErroredParameter::Error2, conflict_Flow_Plato         );
    conf_PlatoTInsp        = new Conflict(ErroredParameter::Error2, conflict_Plato_TInsp        );
    conf_RBTInsp           = new Conflict(ErroredParameter::Error2, conflict_RB_TInsp           );
    conf_TrigModePTrigPEEP = new Conflict(ErroredParameter::Error2, conflict_TrigMode_PTrig_PEEP);
    conf_FTrigFSupp        = new Conflict(ErroredParameter::Error2, conflict_FTrig_FSupp        );
    conf_PEEPPMaxCMVVCV    = new Conflict(ErroredParameter::Error2, conflict_PEEP_PMax_CMVVCV   );
    conf_PEEPPMaxCMVPCV    = new Conflict(ErroredParameter::Error2, conflict_PEEP_PMax_CMVPCV   );
    conf_PEEPPMaxPSupp     = new Conflict(ErroredParameter::Error2, conflict_PEEP_PMax_PSupp    );
    conf_PEEPPMaxPCV_VG    = new Conflict(ErroredParameter::Error2, conflict_PEEP_PMax_PCV_VG   );
    conf_Tsense            = new Conflict(ErroredParameter::Error2, conflict_Tsense             );
    conf_PInspPEEPPMax     = new Conflict(ErroredParameter::Error2, conflict_PInsp_PEEP_PMax    );
    conf_HightPMax         = new Conflict(ErroredParameter::Error2, conflict_HightPMax          );
    conf_VapneaRBapnea     = new Conflict(ErroredParameter::Error2, conflict_Vapnea_RBapnea     );
    conf_PHighPLow         = new Conflict(ErroredParameter::Error2, conflict_PHigh_PLow         );
    conf_PSPLow            = new Conflict(ErroredParameter::Error2, conflict_PS_PLow            );
    conf_THighTLow         = new Conflict(ErroredParameter::Error2, conflict_THigh_TLow         );

    pr_FiO2     = new ParamRule(&dpFiO2     ,21 , 21 , 100,  100);      // CMV/VCV CMV/PCV SIMV/PC SIMV/VC
    pr_PMax     = new ParamRule(&dpPMax     ,10 , 10 , 85 ,   85);      // CMV/VCV CMV/PCV SIMV/PC SIMV/VC
    pr_RB       = new ParamRule(&dpRB       ,15 ,  3 , 80 ,   60);      // CMV/VCV
    pr_RB_2     = new ParamRule(&dpRB       ,15 ,  4 , 80 ,   60);      // CMV/PCV
    pr_RB_3     = new ParamRule(&dpRB       ,1 ,  1 , 30 ,   30);       // SIMV/PC SIMV/VC
    pr_PEEP     = new ParamRule(&dpPEEP     , 0 ,  0 , 25 ,   25);      // CMV/VCV CMV/PCV SIMV/PC SIMV/VC
    pr_TInsp    = new ParamRule(&dpTInsp    ,200 , 200 , 3000,  3000);  // CMV/VCV CMV/PCV SIMV/PC SIMV/VC
    pr_Pramp    = new ParamRule(&dpPramp    ,50  , 50 , 2000 ,   2000); // CMV/VCV CMV/PCV SIMV/PC SIMV/VC
    pr_FSupp    = new ParamRule(&dpFSupp    ,0 , 0 , 30,  30);          // CMV/VCV CMV/PCV
    pr_PTrig    = new ParamRule(&dpPTrig    ,0 , 0 , 200 ,   200);      // CMV/VCV CMV/PCV
    pr_PTrig_2  = new ParamRule(&dpPTrig    ,10 , 10 , 200 ,   200);    // SIMV/PC SIMV/VC
    pr_FTrig    = new ParamRule(&dpFTrig    ,0 , 0 , 20,  20);          // CMV/VCV CMV/PCV
    pr_FTrig_2  = new ParamRule(&dpFTrig    ,1 , 1 , 10,  20);          // SIMV/PC SIMV/VC
    pr_PInsp    = new ParamRule(&dpPInsp    ,21 , 21 , 100,  100);      // CMV/PCV
    pr_PSupp    = new ParamRule(&dpPSupp    ,0 , 0 , 80 ,   80);        // SIMV/PC SIMV/VC





    pr_VInsp    = new ParamRule(&dpVInsp    ,21 , 21 , 100,  100);
    pr_Plato    = new ParamRule(&dpPlato    ,10 , 10 , 85 ,   85);
    pr_FormFlow = new ParamRule(&dpFormFlow ,21 , 21 , 100,  100);

    pr_PHigh    = new ParamRule(&dpPHigh    ,10 , 10 , 85 ,   85);
    pr_PLow     = new ParamRule(&dpPLow     ,21 , 21 , 100,  100);
    pr_THigh    = new ParamRule(&dpTHigh    ,10 , 10 , 85 ,   85);
    pr_TLow     = new ParamRule(&dpTLow     ,21 , 21 , 100,  100);


    pr_TrigWnd  = new ParamRule(&dpTrigWnd  ,10 , 10 , 85 ,   85);

    params_CMVVCV.append(pr_FiO2    );
    params_CMVVCV.append(pr_PMax    );
    params_CMVVCV.append(pr_RB      );
    params_CMVVCV.append(pr_PEEP    );
    params_CMVVCV.append(pr_VInsp   );
    params_CMVVCV.append(pr_TInsp   );
    params_CMVVCV.append(pr_Plato   );

    params_CMVPCV.append(pr_FormFlow);
    params_CMVPCV.append(pr_PTrig   );
    params_CMVPCV.append(pr_FTrig   );
    params_CMVPCV.append(pr_PSupp   );
    params_CMVPCV.append(pr_PInsp   );
    params_CMVPCV.append(pr_PHigh   );
    params_CMVPCV.append(pr_PLow    );
}

