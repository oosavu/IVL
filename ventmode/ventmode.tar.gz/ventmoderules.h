#ifndef VENTMODERULES_H
#define VENTMODERULES_H

#include <QObject>
#include "ventmodetypes.h"
#include "ventmodemanager.h"

/// @name задаваемые параметры.
/// @{
VentDigitParameter dpFiO2     ;
VentDigitParameter dpPMax     ;
VentDigitParameter dpRB       ;
VentDigitParameter dpPEEP     ;
VentDigitParameter dpVInsp    ;
VentDigitParameter dpTInsp    ;
VentDigitParameter dpPlato    ;
VentDigitParameter dpFormFlow ;
VentDigitParameter dpPTrig    ;
VentDigitParameter dpFTrig    ;
VentDigitParameter dpPSupp    ;
VentDigitParameter dpPInsp    ;
VentDigitParameter dpPHigh    ;
VentDigitParameter dpPLow     ;
VentDigitParameter dpTHigh    ;
VentDigitParameter dpTLow     ;
VentDigitParameter dpPramp    ;
VentDigitParameter dpFSupp    ;
VentDigitParameter dpTrigWnd  ;
/// @}

/// @name задаваемые параметры, связанные с АПНОЭ
/// @{
BoolParameter  bpApneaRegime ;
DigitParameter dpApneaWeight ;
DigitParameter dpApneaV      ;
DigitParameter dpApneaPi     ;
DigitParameter dpApneaRB     ;
DigitParameter dpApneaT      ;
/// @}

/// @name дополнительные параметры вентиляции
/// @{
EditableDigitParameter edpPramp        ;
EditableDigitParameter edpComplPeriod  ;
EditableDigitParameter edpFEnd         ;
EditableDigitParameter edpDisconSens   ;
EditableDigitParameter edpPmaxLim      ;
EditableDigitParameter edpTiLim        ;
EditableBoolParameter  ebpSigh         ;
BoolParameter          bpAge           ; //true = child
BoolParameter          bpTrigMode      ; //true = po potoku
/// @}

/// @name вычисляемые параметры.
/// @{
VentDependenceParameter  bdpTiTc    ;
VentDependenceParameter  bdpFlow    ;
VentDependenceParameter  bdpFlowMax ;
VentDependenceParameter  bdpTexp    ;
VentDependenceParameter  bdpTsense  ;
VentDependenceParameter  bdpTplato  ;
VentDependenceParameter  bdpMV      ;
VentDependenceParameter  bdpPTrig   ;
VentDependenceParameter  bdpFTrig   ;
VentDependenceParameter  bdpTramp   ;
/// @}

/// @}
/// функции вычисления зависимых параметров.
/// @{
qint32 calcTExp();
qint32 calcTSense();
qint32 calcTPlato();
qint32 calcTiTc();
qint32 calcMV();
qint32 calcFlow1();
qint32 calcFlow2();
qint32 calcFlowMax1();
qint32 calcFlowMax2();
qint32 calcTramp();
qint32 calcPtrig();
qint32 calcFtrig();
/// @}

/// функции вычисления конфликтов
/// @{
bool conflict_HightFlow();
bool conflict_FormFlow_FlowMax();
bool conflict_Flow_Plato();
bool conflict_Plato_TInsp();
bool conflict_RB_TInsp();
bool conflict_TrigMode_PTrig_PEEP();
bool conflict_FTrig_FSupp();
bool conflict_PEEP_PMax_CMVVCV();
bool conflict_PEEP_PMax_CMVPCV();
bool conflict_PEEP_PMax_PSupp();
bool conflict_PEEP_PMax_PCV_VG();
bool conflict_Tsense();
bool conflict_PInsp_PEEP_PMax();
bool conflict_HightPMax();
bool conflict_Vapnea_RBapnea();
bool conflict_PHigh_PLow();
bool conflict_PS_PLow();
bool conflict_THigh_TLow();
/// @}

/// Правила для вычисляемых параметров
DependenceParamRule* dr_TExp    ;
DependenceParamRule* dr_TSense  ;
DependenceParamRule* dr_TPlato  ;
DependenceParamRule* dr_TiTc    ;
DependenceParamRule* dr_MV      ;
DependenceParamRule* dr_Flow1   ;
DependenceParamRule* dr_Flow2   ;
DependenceParamRule* dr_FlowMax1;
DependenceParamRule* dr_FlowMax2;
DependenceParamRule* dr_Tramp   ;
DependenceParamRule* dr_PTrig   ;
DependenceParamRule* dr_FTrig   ;

///конфликты
Conflict* conf_HightFlow         ;
Conflict* conf_FormFlowFlowMax   ;
Conflict* conf_FlowPlato         ;
Conflict* conf_PlatoTInsp        ;
Conflict* conf_RBTInsp           ;
Conflict* conf_TrigModePTrigPEEP ;
Conflict* conf_FTrigFSupp        ;
Conflict* conf_PEEPPMaxCMVVCV    ;
Conflict* conf_PEEPPMaxCMVPCV    ;
Conflict* conf_PEEPPMaxPSupp     ;
Conflict* conf_PEEPPMaxPCV_VG    ;
Conflict* conf_Tsense            ;
Conflict* conf_PInspPEEPPMax     ;
Conflict* conf_HightPMax         ;
Conflict* conf_VapneaRBapnea     ;
Conflict* conf_PHighPLow         ;
Conflict* conf_PSPLow            ;
Conflict* conf_THighTLow         ;

///правила для параметров
ParamRule* pr_FiO2          ;
ParamRule* pr_PMax          ;
ParamRule* pr_RB            ;
ParamRule* pr_RB_2          ;
ParamRule* pr_RB_3          ;
ParamRule* pr_PEEP          ;
ParamRule* pr_VInsp         ;
ParamRule* pr_TInsp         ;
ParamRule* pr_Plato         ;
ParamRule* pr_FormFlow      ;
ParamRule* pr_PTrig         ;
ParamRule* pr_PTrig_2       ;
ParamRule* pr_FTrig         ;
ParamRule* pr_FTrig_2       ;
ParamRule* pr_PSupp         ;
ParamRule* pr_PInsp         ;
ParamRule* pr_PHigh         ;
ParamRule* pr_PLow          ;
ParamRule* pr_THigh         ;
ParamRule* pr_TLow          ;
ParamRule* pr_Pramp         ;
ParamRule* pr_FSupp         ;
ParamRule* pr_TrigWnd       ;

QList<ParamRule*> params_CMVVCV;
QList<ParamRule*> params_CMVPCV;




void initRules();


#endif // VENTMODERULES_H
